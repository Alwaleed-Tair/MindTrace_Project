import { type FormEvent, type ReactNode, useEffect, useMemo, useState } from 'react';
import {
  ArrowDownAZ,
  ArrowLeft,
  ArrowRight,
  AudioLines,
  Beaker,
  Bell,
  BookOpen,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  FileText,
  FlaskConical,
  LayoutDashboard,
  Lightbulb,
  LockKeyhole,
  Mail,
  Menu,
  Moon,
  MoreHorizontal,
  PencilLine,
  Plus,
  Search,
  Settings,
  SlidersHorizontal,
  Sparkles,
  Sun,
  Tag,
  Timer,
  Trash2,
  X,
} from 'lucide-react';
import { Link, Route, Switch, useLocation, useParams } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import NotFound from '@/pages/not-found';

const logoMarkSrc = '/mindtrace-mark.png';

type Language = 'en' | 'ar';
type Theme = 'light' | 'dark';
type Status = 'Active' | 'Paused' | 'Completed';
type Tab = 'overview' | 'notes' | 'insights';

type Note = {
  id: string;
  text: string;
  time: string;
  kind: 'observation' | 'hypothesis' | 'decision';
};

type Experiment = {
  id: string;
  title: string;
  code: string;
  summary: string;
  status: Status;
  updated: string;
  duration: string;
  originality: number;
  tags: string[];
  notes: Note[];
  color: string;
};

const initialExperiments: Experiment[] = [
  {
    id: 'ex-204',
    title: 'Ambient temperature & reaction time',
    code: 'EXP-204',
    summary: 'Mapping how a small temperature shift changes the catalyst response curve.',
    status: 'Active',
    updated: '12 min ago',
    duration: '01:42:18',
    originality: 82,
    tags: ['Catalysis', 'Kinetics'],
    color: 'mint',
    notes: [
      { id: 'n-1', text: 'At 23.4°C the color change appeared 8 seconds earlier than the baseline run.', time: '09:42', kind: 'observation' },
      { id: 'n-2', text: 'Check whether the room ventilation is introducing a second variable.', time: '09:56', kind: 'hypothesis' },
    ],
  },
  {
    id: 'ex-203',
    title: 'Low-light plant signaling',
    code: 'EXP-203',
    summary: 'A quiet study of signal propagation in seedlings under intermittent light.',
    status: 'Paused',
    updated: 'Yesterday',
    duration: '00:48:06',
    originality: 67,
    tags: ['Botany', 'Imaging'],
    color: 'lilac',
    notes: [
      { id: 'n-3', text: 'The third leaf angled toward the lamp after the second light interval.', time: '16:12', kind: 'observation' },
    ],
  },
  {
    id: 'ex-198',
    title: 'Acoustic texture in porous ceramics',
    code: 'EXP-198',
    summary: 'Comparing resonance profiles before and after controlled hydration.',
    status: 'Completed',
    updated: 'Oct 08, 2026',
    duration: '02:14:32',
    originality: 91,
    tags: ['Materials', 'Acoustics'],
    color: 'sand',
    notes: [
      { id: 'n-4', text: 'Sample C has a narrower resonance peak after 40 minutes of hydration.', time: '11:03', kind: 'observation' },
      { id: 'n-5', text: 'The shape is consistent with the micro-pore distribution from scan 04.', time: '11:28', kind: 'decision' },
    ],
  },
  {
    id: 'ex-191',
    title: 'Microcurrent thresholds in gel media',
    code: 'EXP-191',
    summary: 'Finding the response threshold where the gel structure becomes visibly directional.',
    status: 'Completed',
    updated: 'Sep 27, 2026',
    duration: '01:08:44',
    originality: 74,
    tags: ['Electrochemistry'],
    color: 'blue',
    notes: [],
  },
];

const translations = {
  en: {
    signIn: 'Enter your workspace',
    signInSub: 'A focused place for the experiments still unfolding.',
    email: 'Email address',
    emailPlaceholder: 'you@research-lab.com',
    password: 'Password',
    passwordPlaceholder: 'Enter your password',
    remember: 'Remember me',
    forgot: 'Forgot password?',
    signInButton: 'Sign in',
    demo: 'Open demo workspace',
    demoSub: 'No account needed · local demo data',
    language: 'العربية',
    dashboard: 'Workspace',
    experiments: 'Experiments',
    settings: 'Settings',
    help: 'Help & feedback',
    welcome: 'Good morning, Dr. Noor',
    welcomeSub: 'Keep the signal. Let MindTrace hold the details.',
    newExperiment: 'New experiment',
    recent: 'Recent experiments',
    search: 'Search experiments…',
    all: 'All statuses',
    active: 'Active',
    paused: 'Paused',
    completed: 'Completed',
    sort: 'Last updated',
    empty: 'No experiments match this view.',
    emptySub: 'Try another filter or begin a new observation.',
    createTitle: 'Start an experiment',
    createSub: 'Give the work a name. You can add the detail as it happens.',
    title: 'Experiment title',
    titlePlaceholder: 'e.g. Surface tension under vibration',
    summary: 'Working question',
    summaryPlaceholder: 'What are you trying to notice?',
    create: 'Create experiment',
    cancel: 'Cancel',
    overview: 'Overview',
    notes: 'Notes',
    insights: 'Insights',
    addNote: 'Add a written note',
    notePlaceholder: 'Capture what you see, hear, or suspect…',
    saveNote: 'Save note',
    recording: 'Record observation',
    recordingOn: 'Recording locally',
    stop: 'Stop',
    originality: 'Originality signal',
    similar: 'Similar-work signal',
    similarSub: 'No close match in your workspace',
    related: 'Related threads',
    back: 'Back to workspace',
    profile: 'Researcher profile',
    appearance: 'Appearance',
    theme: 'Theme',
    light: 'Light',
    dark: 'Dark',
    langSetting: 'Language',
    saved: 'Saved locally',
  },
  ar: {
    signIn: 'ادخل إلى مساحة عملك',
    signInSub: 'مساحة هادئة للتجارب التي لا تزال تتشكل.',
    email: 'البريد الإلكتروني',
    emailPlaceholder: 'you@research-lab.com',
    password: 'كلمة المرور',
    passwordPlaceholder: 'أدخل كلمة المرور',
    remember: 'تذكرني',
    forgot: 'نسيت كلمة المرور؟',
    signInButton: 'تسجيل الدخول',
    demo: 'افتح مساحة العرض',
    demoSub: 'لا حاجة لحساب · بيانات محلية تجريبية',
    language: 'English',
    dashboard: 'مساحة العمل',
    experiments: 'التجارب',
    settings: 'الإعدادات',
    help: 'المساعدة والملاحظات',
    welcome: 'صباح الخير، د. نور',
    welcomeSub: 'احتفظ بالإشارة. دع MindTrace يحفظ التفاصيل.',
    newExperiment: 'تجربة جديدة',
    recent: 'التجارب الأخيرة',
    search: 'ابحث في التجارب…',
    all: 'كل الحالات',
    active: 'نشطة',
    paused: 'متوقفة',
    completed: 'مكتملة',
    sort: 'آخر تحديث',
    empty: 'لا توجد تجارب مطابقة.',
    emptySub: 'جرّب مرشحاً آخر أو ابدأ ملاحظة جديدة.',
    createTitle: 'ابدأ تجربة',
    createSub: 'امنح العمل اسماً. يمكنك إضافة التفاصيل أثناء حدوثها.',
    title: 'عنوان التجربة',
    titlePlaceholder: 'مثال: التوتر السطحي تحت الاهتزاز',
    summary: 'السؤال البحثي',
    summaryPlaceholder: 'ما الذي تحاول ملاحظته؟',
    create: 'إنشاء التجربة',
    cancel: 'إلغاء',
    overview: 'نظرة عامة',
    notes: 'ملاحظات',
    insights: 'رؤى',
    addNote: 'أضف ملاحظة مكتوبة',
    notePlaceholder: 'سجّل ما تراه أو تسمعه أو تتوقعه…',
    saveNote: 'احفظ الملاحظة',
    recording: 'سجّل ملاحظة',
    recordingOn: 'تسجيل محلي',
    stop: 'إيقاف',
    originality: 'إشارة الأصالة',
    similar: 'إشارة الأعمال المشابهة',
    similarSub: 'لا يوجد تطابق قريب في مساحة عملك',
    related: 'مسارات ذات صلة',
    back: 'العودة إلى مساحة العمل',
    profile: 'ملف الباحث',
    appearance: 'المظهر',
    theme: 'السمة',
    light: 'فاتح',
    dark: 'داكن',
    langSetting: 'اللغة',
    saved: 'محفوظ محلياً',
  },
} as const;

function Logo({ compact = false, inverse = false }: { compact?: boolean; inverse?: boolean }) {
  return (
    <div className={`mindtrace-logo ${compact ? 'mindtrace-logo-compact' : ''} ${inverse ? 'mindtrace-logo-inverse' : ''}`}>
      <img src={logoMarkSrc} alt="" data-testid="img-mindtrace-logo" />
      {!compact && <span className="mindtrace-wordmark">Mind<span>Trace</span></span>}
    </div>
  );
}

function LanguageToggle({ language, setLanguage, inverse = false }: { language: Language; setLanguage: (value: Language) => void; inverse?: boolean }) {
  return (
    <button
      type="button"
      onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
      className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold transition hover:-translate-y-0.5 ${inverse ? 'border-white/20 bg-white/10 text-white hover:bg-white/15' : 'border-border bg-card text-muted-foreground hover:border-primary/50 hover:text-foreground'}`}
      data-testid="button-toggle-language"
    >
      <span className="font-mono text-[10px]">{language === 'en' ? 'EN' : 'ع'}</span>
      <span>{translations[language].language}</span>
    </button>
  );
}

function ThemeToggle({ theme, setTheme, compact = false }: { theme: Theme; setTheme: (value: Theme) => void; compact?: boolean }) {
  return (
    <button
      type="button"
      onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
      className={`inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-card text-muted-foreground transition hover:border-primary/50 hover:text-foreground ${compact ? 'h-9 w-9' : 'px-3 py-2 text-xs font-semibold'}`}
      aria-label="Toggle theme"
      data-testid="button-toggle-theme"
    >
      {theme === 'light' ? <Moon size={15} /> : <Sun size={15} />}
      {!compact && <span>{theme === 'light' ? 'Dark mode' : 'Light mode'}</span>}
    </button>
  );
}

function SignInPage({ language, setLanguage, onEnter }: { language: Language; setLanguage: (value: Language) => void; onEnter: () => void }) {
  const t = translations[language];
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    onEnter();
  };

  return (
    <main className="app-noise min-h-[100dvh] bg-background" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <header className="mx-auto flex w-full max-w-6xl items-center justify-between px-5 py-5 sm:px-8 sm:py-7">
        <Logo />
        <LanguageToggle language={language} setLanguage={setLanguage} />
      </header>
      <section className="flex min-h-[calc(100dvh-92px)] items-center justify-center px-5 py-10 sm:px-8">
        <div className="w-full max-w-[430px] animate-in">
          <div className="rounded-3xl border border-border bg-card p-6 shadow-[0_24px_70px_hsl(var(--primary)/.08)] sm:p-9">
            <div className="mb-8 text-center">
              <div className="mb-6 flex justify-center sm:hidden"><Logo compact /></div>
              <p className="mb-3 font-mono text-[10px] uppercase tracking-[0.25em] text-primary">MindTrace / 01</p>
              <h1 className="text-3xl font-semibold tracking-[-0.04em] sm:text-4xl">{t.signIn}</h1>
              <p className="mt-3 text-sm leading-6 text-muted-foreground">{t.signInSub}</p>
            </div>
            <form onSubmit={submit} className="space-y-5">
              <label className="block">
                <span className="mb-2 block text-xs font-semibold">{t.email}</span>
                <span className="flex h-12 items-center gap-3 rounded-xl border border-input bg-background px-3.5 transition focus-within:border-primary">
                  <Mail size={16} className="text-muted-foreground" />
                  <input type="email" autoComplete="email" required value={email} onChange={(event) => setEmail(event.target.value)} placeholder={t.emailPlaceholder} className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground/55" data-testid="input-email" />
                </span>
              </label>
              <label className="block">
                <span className="mb-2 block text-xs font-semibold">{t.password}</span>
                <span className="flex h-12 items-center gap-3 rounded-xl border border-input bg-background px-3.5 transition focus-within:border-primary">
                  <LockKeyhole size={16} className="text-muted-foreground" />
                  <input type="password" autoComplete="current-password" required value={password} onChange={(event) => setPassword(event.target.value)} placeholder={t.passwordPlaceholder} className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground/55" data-testid="input-password" />
                </span>
              </label>
              <div className="flex items-center justify-between gap-4">
                <label className="flex items-center gap-2 text-xs text-muted-foreground">
                  <input type="checkbox" defaultChecked className="accent-primary" />
                  {t.remember}
                </label>
                <button type="button" className="text-xs font-semibold text-primary hover:underline">{t.forgot}</button>
              </div>
              <button type="submit" className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3.5 text-sm font-semibold text-primary-foreground shadow-[0_10px_25px_hsl(var(--primary)/.15)] transition hover:-translate-y-0.5" data-testid="button-sign-in">
                {t.signInButton}
                <span dir="ltr">{language === 'ar' ? <ArrowLeft size={16} /> : <ArrowRight size={16} />}</span>
              </button>
            </form>
            <div className="my-6 flex items-center gap-3 text-[10px] uppercase tracking-[.18em] text-muted-foreground/60"><span className="h-px flex-1 bg-border" />or<span className="h-px flex-1 bg-border" /></div>
            <button type="button" onClick={onEnter} className="flex w-full items-center justify-center rounded-xl border border-border bg-background px-5 py-3 text-sm font-semibold text-foreground transition hover:border-primary/50 hover:bg-muted" data-testid="button-enter-demo">{t.demo}</button>
            <p className="mt-4 text-center text-[11px] text-muted-foreground">{t.demoSub}</p>
          </div>
        </div>
      </section>
    </main>
  );
}

function Sidebar({ language, setLanguage, theme, setTheme, mobileOpen, setMobileOpen }: { language: Language; setLanguage: (value: Language) => void; theme: Theme; setTheme: (value: Theme) => void; mobileOpen: boolean; setMobileOpen: (value: boolean) => void }) {
  const t = translations[language];
  const [location] = useLocation();
  const nav = [
    { href: '/dashboard', label: t.dashboard, icon: LayoutDashboard },
    { href: '/dashboard', label: t.experiments, icon: FlaskConical },
  ];
  return (
    <>
      {mobileOpen && <button aria-label="Close navigation" className="fixed inset-0 z-30 bg-[hsl(var(--foreground)/.28)] md:hidden" onClick={() => setMobileOpen(false)} data-testid="button-close-mobile-nav" />}
      <aside className={`fixed inset-y-0 z-40 flex w-[250px] flex-col bg-sidebar px-4 py-5 text-sidebar-foreground transition-transform duration-300 md:relative md:translate-x-0 ${language === 'ar' ? `right-0 ${mobileOpen ? 'translate-x-0' : 'translate-x-full'}` : `left-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}`} dir={language === 'ar' ? 'rtl' : 'ltr'}>
        <div className="flex items-center justify-between px-2">
          <Logo inverse />
          <button className="rounded-lg p-1.5 text-sidebar-foreground/60 hover:bg-white/10 hover:text-white md:hidden" onClick={() => setMobileOpen(false)} aria-label="Close navigation" data-testid="button-close-sidebar"><X size={18} /></button>
        </div>
        <div className="mt-10 px-2">
          <span className="font-mono text-[9px] uppercase tracking-[.25em] text-sidebar-foreground/40">Workspace</span>
          <nav className="mt-3 space-y-1">
            {nav.map(({ href, label, icon: Icon }, index) => <Link href={href} key={`${label}-${index}`} onClick={() => setMobileOpen(false)} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition ${location === href ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-sm' : 'text-sidebar-foreground/62 hover:bg-white/[.07] hover:text-white'}`} data-testid={`link-nav-${index === 0 ? 'dashboard' : 'experiments'}`}><Icon size={16} /><span>{label}</span>{index === 0 && <span className="ms-auto h-1.5 w-1.5 rounded-full bg-accent" />}</Link>)}
          </nav>
        </div>
        <div className="mt-auto space-y-1">
          <Link href="/settings" onClick={() => setMobileOpen(false)} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition ${location === '/settings' ? 'bg-sidebar-primary text-sidebar-primary-foreground' : 'text-sidebar-foreground/62 hover:bg-white/[.07] hover:text-white'}`} data-testid="link-nav-settings"><Settings size={16} /><span>{t.settings}</span></Link>
          <button type="button" className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-sidebar-foreground/62 transition hover:bg-white/[.07] hover:text-white" onClick={() => window.alert('MindTrace demo feedback is ready for your notes.')} data-testid="button-help"><CircleHelp size={16} /><span>{t.help}</span></button>
          <div className="mt-5 flex items-center gap-3 border-t border-sidebar-border px-2 pt-4">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-accent text-xs font-bold text-accent-foreground">N</div>
            <div className="min-w-0 flex-1"><p className="truncate text-xs font-semibold text-sidebar-foreground">Dr. Noor Rahman</p><p className="truncate text-[10px] text-sidebar-foreground/45">Materials lab</p></div>
            <ThemeToggle theme={theme} setTheme={setTheme} compact />
          </div>
        </div>
      </aside>
    </>
  );
}

function AppShell({ children, language, setLanguage, theme, setTheme }: { children: ReactNode; language: Language; setLanguage: (value: Language) => void; theme: Theme; setTheme: (value: Theme) => void }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <div className="app-noise flex min-h-[100dvh] bg-background" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <Sidebar language={language} setLanguage={setLanguage} theme={theme} setTheme={setTheme} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <main className="dashboard-grid min-w-0 flex-1">
        <header className="flex h-[70px] items-center justify-between border-b border-border bg-background/75 px-5 backdrop-blur-md sm:px-8">
          <button type="button" className="rounded-xl border border-border bg-card p-2 text-muted-foreground md:hidden" onClick={() => setMobileOpen(true)} aria-label="Open navigation" data-testid="button-open-mobile-nav"><Menu size={18} /></button>
          <div className="ms-auto flex items-center gap-2 sm:gap-3"><LanguageToggle language={language} setLanguage={setLanguage} /><Bell size={17} className="hidden text-muted-foreground sm:block" /><div className="h-8 w-8 rounded-full bg-primary/15 text-center text-xs font-bold leading-8 text-primary" data-testid="avatar-user">NR</div></div>
        </header>
        <div className="mx-auto max-w-[1360px] p-5 sm:p-8 lg:p-10">{children}</div>
      </main>
    </div>
  );
}

function StatusPill({ status, language }: { status: Status; language: Language }) {
  const labels: Record<Language, Record<Status, string>> = { en: { Active: 'Active', Paused: 'Paused', Completed: 'Completed' }, ar: { Active: 'نشطة', Paused: 'متوقفة', Completed: 'مكتملة' } };
  const style = status === 'Active' ? 'bg-primary/12 text-primary' : status === 'Paused' ? 'bg-accent/40 text-accent-foreground' : 'bg-muted text-muted-foreground';
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-semibold ${style}`} data-testid={`status-${status.toLowerCase()}`}><span className={`h-1.5 w-1.5 rounded-full ${status === 'Active' ? 'bg-primary' : status === 'Paused' ? 'bg-amber-500' : 'bg-muted-foreground/50'}`} />{labels[language][status]}</span>;
}

function CreateExperimentDialog({ language, onClose, onCreate }: { language: Language; onClose: () => void; onCreate: (title: string, summary: string) => void }) {
  const t = translations[language];
  const [title, setTitle] = useState('');
  const [summary, setSummary] = useState('');
  const submit = () => { if (title.trim()) onCreate(title.trim(), summary.trim() || 'A new research thread, ready to be observed.'); };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[hsl(var(--foreground)/.32)] p-4 backdrop-blur-sm" role="dialog" aria-modal="true" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <div className="w-full max-w-lg animate-in rounded-3xl border border-border bg-card p-6 shadow-2xl sm:p-8">
        <div className="flex items-start justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[.25em] text-primary">New thread / 01</p><h2 className="mt-2 text-2xl font-semibold tracking-[-.04em]">{t.createTitle}</h2><p className="mt-2 text-sm text-muted-foreground">{t.createSub}</p></div><button type="button" onClick={onClose} className="rounded-xl p-2 text-muted-foreground hover:bg-muted" aria-label="Close create dialog" data-testid="button-close-create"><X size={18} /></button></div>
        <div className="mt-8 space-y-5">
          <label className="block"><span className="mb-2 block text-xs font-semibold">{t.title}</span><input autoFocus value={title} onChange={(event) => setTitle(event.target.value)} placeholder={t.titlePlaceholder} className="w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition placeholder:text-muted-foreground/55 focus:border-primary" data-testid="input-experiment-title" /></label>
          <label className="block"><span className="mb-2 block text-xs font-semibold">{t.summary}</span><textarea value={summary} onChange={(event) => setSummary(event.target.value)} placeholder={t.summaryPlaceholder} rows={3} className="w-full resize-none rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition placeholder:text-muted-foreground/55 focus:border-primary" data-testid="input-experiment-summary" /></label>
        </div>
        <div className="mt-8 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end"><button type="button" onClick={onClose} className="rounded-xl px-4 py-2.5 text-sm font-semibold text-muted-foreground hover:bg-muted" data-testid="button-cancel-create">{t.cancel}</button><button type="button" onClick={submit} disabled={!title.trim()} className="rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-45" data-testid="button-submit-create">{t.create}</button></div>
      </div>
    </div>
  );
}

function ExperimentCard({ experiment, language }: { experiment: Experiment; language: Language }) {
  return (
    <Link href={`/experiments/${experiment.id}`} className="group block rounded-2xl border border-border bg-card p-5 transition duration-300 hover:-translate-y-1 hover:border-primary/45 hover:shadow-[0_14px_30px_hsl(var(--primary)/.08)]" data-testid={`card-experiment-${experiment.id}`}>
      <div className="flex items-start justify-between gap-4"><div className={`flex h-10 w-10 items-center justify-center rounded-xl ${experiment.color === 'mint' ? 'bg-accent/45 text-primary' : experiment.color === 'lilac' ? 'bg-violet-100 text-violet-700 dark:bg-violet-950 dark:text-violet-300' : experiment.color === 'sand' ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300' : 'bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-300'}`}><Beaker size={18} /></div><MoreHorizontal size={18} className="text-muted-foreground/50 transition group-hover:text-primary" /></div>
      <div className="mt-5"><div className="flex flex-wrap items-center gap-2"><StatusPill status={experiment.status} language={language} /><span className="font-mono text-[10px] text-muted-foreground">{experiment.code}</span></div><h3 className="mt-3 line-clamp-1 text-[17px] font-semibold tracking-[-.03em]">{experiment.title}</h3><p className="mt-2 line-clamp-2 min-h-[40px] text-xs leading-5 text-muted-foreground">{experiment.summary}</p></div>
      <div className="mt-5 flex items-center justify-between border-t border-border pt-4 text-[10px] text-muted-foreground"><span className="flex items-center gap-1.5"><Clock3 size={12} />{experiment.updated}</span><span className="font-mono text-primary">{experiment.originality}% signal</span></div>
    </Link>
  );
}

function DashboardPage({ experiments, setExperiments, language, theme, setTheme }: { experiments: Experiment[]; setExperiments: (value: Experiment[]) => void; language: Language; theme: Theme; setTheme: (value: Theme) => void }) {
  const t = translations[language];
  const [, setLocation] = useLocation();
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<'All' | Status>('All');
  const [sortNewest, setSortNewest] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const filtered = useMemo(() => experiments.filter((experiment) => (filter === 'All' || experiment.status === filter) && `${experiment.title} ${experiment.summary} ${experiment.tags.join(' ')}`.toLowerCase().includes(query.toLowerCase())).sort((a, b) => sortNewest ? b.id.localeCompare(a.id) : a.id.localeCompare(b.id)), [experiments, filter, query, sortNewest]);
  const activeCount = experiments.filter((experiment) => experiment.status === 'Active').length;
  const create = (title: string, summary: string) => { const id = `ex-${Math.floor(205 + Math.random() * 90)}`; const created: Experiment = { id, title, code: `EXP-${id.slice(3)}`, summary, status: 'Active', updated: 'Just now', duration: '00:00:00', originality: 50, tags: ['New thread'], notes: [], color: 'mint' }; setExperiments([created, ...experiments]); setShowCreate(false); setLocation(`/experiments/${id}`); };
  return (
    <>
      <div className="animate-in flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="font-mono text-[10px] uppercase tracking-[.25em] text-primary">Tuesday / October 14, 2026</p><h1 className="mt-3 text-3xl font-semibold tracking-[-.055em] sm:text-4xl">{t.welcome}</h1><p className="mt-2 text-sm text-muted-foreground">{t.welcomeSub}</p></div><button type="button" onClick={() => setShowCreate(true)} className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground shadow-[0_10px_25px_hsl(var(--primary)/.15)] transition hover:-translate-y-0.5" data-testid="button-new-experiment"><Plus size={17} />{t.newExperiment}</button></div>
      <div className="mt-9 grid gap-4 sm:grid-cols-3">
        {[{ icon: FlaskConical, label: 'Active threads', value: String(activeCount).padStart(2, '0'), note: 'in motion' }, { icon: FileText, label: 'Notes this week', value: '19', note: '+4 from last week' }, { icon: Lightbulb, label: 'Avg. originality', value: '78%', note: 'across all work' }].map(({ icon: Icon, label, value, note }, index) => <div key={label} className={`animate-in delay-${index + 1} relative overflow-hidden rounded-2xl border border-border bg-card p-5`}><div className="flex items-center justify-between"><span className="text-xs text-muted-foreground">{label}</span><Icon size={16} className="text-primary/70" /></div><div className="mt-4 flex items-end gap-2"><strong className="font-mono text-3xl tracking-[-.08em]">{value}</strong><span className="mb-1 text-[10px] text-muted-foreground">{note}</span></div><div className="absolute -bottom-8 -right-5 h-24 w-24 rounded-full border border-primary/10" /></div>)}
      </div>
      <section className="mt-10 animate-in delay-3">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center"><div><h2 className="text-xl font-semibold tracking-[-.04em]">{t.recent}</h2><p className="mt-1 text-xs text-muted-foreground">{filtered.length} threads in your workspace</p></div><div className="flex items-center gap-2"><button type="button" onClick={() => setSortNewest(!sortNewest)} className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2 text-xs font-semibold text-muted-foreground transition hover:border-primary/40 hover:text-foreground" data-testid="button-sort-experiments"><ArrowDownAZ size={14} />{t.sort}<ChevronDown size={13} className={sortNewest ? '' : 'rotate-180'} /></button><ThemeToggle theme={theme} setTheme={setTheme} compact /></div></div>
        <div className="mt-5 flex flex-col gap-3 sm:flex-row"><label className="relative block flex-1"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" /><input type="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t.search} className="h-11 w-full rounded-xl border border-border bg-card pl-10 pr-4 text-sm outline-none transition placeholder:text-muted-foreground/60 focus:border-primary" data-testid="input-search-experiments" /></label><label className="relative"><SlidersHorizontal size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" /><select value={filter} onChange={(event) => setFilter(event.target.value as 'All' | Status)} className="h-11 w-full min-w-[145px] appearance-none rounded-xl border border-border bg-card pl-9 pr-8 text-xs font-semibold outline-none focus:border-primary" data-testid="select-status-filter"><option value="All">{t.all}</option><option value="Active">{t.active}</option><option value="Paused">{t.paused}</option><option value="Completed">{t.completed}</option></select><ChevronDown size={14} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" /></label></div>
        {filtered.length > 0 ? <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-3">{filtered.map((experiment, index) => <div className={`animate-in delay-${Math.min(index + 1, 4)}`} key={experiment.id}><ExperimentCard experiment={experiment} language={language} /></div>)}</div> : <div className="mt-5 rounded-2xl border border-dashed border-border bg-card/70 px-6 py-16 text-center"><Search className="mx-auto text-primary/60" size={25} /><p className="mt-4 text-sm font-semibold">{t.empty}</p><p className="mt-1 text-xs text-muted-foreground">{t.emptySub}</p></div>}
      </section>
      {showCreate && <CreateExperimentDialog language={language} onClose={() => setShowCreate(false)} onCreate={create} />}
    </>
  );
}

function CircularScore({ value }: { value: number }) {
  const radius = 39;
  const circumference = 2 * Math.PI * radius;
  return <div className="relative h-28 w-28"><svg viewBox="0 0 100 100" className="h-full w-full -rotate-90"><circle cx="50" cy="50" r={radius} fill="none" stroke="hsl(var(--muted))" strokeWidth="7" /><circle cx="50" cy="50" r={radius} fill="none" stroke="hsl(var(--primary))" strokeLinecap="round" strokeWidth="7" strokeDasharray={circumference} strokeDashoffset={circumference * (1 - value / 100)} /></svg><div className="absolute inset-0 flex flex-col items-center justify-center"><strong className="font-mono text-2xl tracking-[-.08em]">{value}</strong><span className="text-[9px] text-muted-foreground">/ 100</span></div></div>;
}

function NotesPanel({ experiment, language, onAddNote }: { experiment: Experiment; language: Language; onAddNote: (text: string) => void }) {
  const t = translations[language];
  const [text, setText] = useState('');
  const save = () => { if (text.trim()) { onAddNote(text.trim()); setText(''); } };
  return <div><div className="rounded-2xl border border-border bg-card p-5 sm:p-6"><div className="flex items-center justify-between"><div><h3 className="text-sm font-semibold">{t.addNote}</h3><p className="mt-1 text-xs text-muted-foreground">Written notes stay attached to this thread.</p></div><PencilLine size={17} className="text-primary" /></div><textarea value={text} onChange={(event) => setText(event.target.value)} rows={4} placeholder={t.notePlaceholder} className="mt-5 w-full resize-none rounded-xl border border-input bg-background px-4 py-3 text-sm leading-6 outline-none transition placeholder:text-muted-foreground/55 focus:border-primary" data-testid="textarea-new-note" /><div className="mt-3 flex justify-end"><button type="button" disabled={!text.trim()} onClick={save} className="rounded-xl bg-primary px-4 py-2.5 text-xs font-semibold text-primary-foreground transition hover:-translate-y-0.5 disabled:opacity-40" data-testid="button-save-note">{t.saveNote}</button></div></div><div className="mt-7"><div className="mb-3 flex items-center justify-between"><h3 className="text-sm font-semibold">Timeline</h3><span className="font-mono text-[10px] text-muted-foreground">{experiment.notes.length} entries</span></div><div className="space-y-0">{experiment.notes.length ? experiment.notes.map((note, index) => <div key={note.id} className="relative flex gap-4 pb-6"><div className="flex flex-col items-center"><span className={`mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${note.kind === 'hypothesis' ? 'bg-accent text-accent-foreground' : 'bg-primary/12 text-primary'}`}><span className="h-1.5 w-1.5 rounded-full bg-current" /></span>{index !== experiment.notes.length - 1 && <span className="w-px flex-1 bg-border" />}</div><div className="min-w-0 pt-1"><div className="flex flex-wrap items-center gap-2"><span className="font-mono text-[10px] text-muted-foreground">{note.time}</span><span className="text-[10px] font-semibold uppercase tracking-[.1em] text-primary">{note.kind}</span></div><p className="mt-2 text-sm leading-6 text-foreground/80">{note.text}</p></div></div>) : <div className="rounded-xl border border-dashed border-border px-4 py-8 text-center text-xs text-muted-foreground">Your first observation will appear here.</div>}</div></div></div>;
}

function ExperimentPage({ experiments, setExperiments, language }: { experiments: Experiment[]; setExperiments: (value: Experiment[]) => void; language: Language }) {
  const t = translations[language];
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const [tab, setTab] = useState<Tab>('overview');
  const [recording, setRecording] = useState(false);
  const experiment = experiments.find((item) => item.id === id) ?? experiments[0];
  const addNote = (text: string) => setExperiments(experiments.map((item) => item.id === experiment.id ? { ...item, notes: [...item.notes, { id: `n-${Date.now()}`, text, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), kind: 'observation' }] } : item));
  if (!experiment) return null;
  return <div className="animate-in">
    <button type="button" onClick={() => setLocation('/dashboard')} className="mb-7 inline-flex items-center gap-2 text-xs font-semibold text-muted-foreground transition hover:text-primary" data-testid="button-back-dashboard"><ArrowLeft size={15} />{t.back}</button>
    <div className="flex flex-col justify-between gap-5 lg:flex-row lg:items-end"><div><div className="flex flex-wrap items-center gap-3"><StatusPill status={experiment.status} language={language} /><span className="font-mono text-[10px] text-muted-foreground">{experiment.code}</span></div><h1 className="mt-4 max-w-3xl text-3xl font-semibold tracking-[-.055em] sm:text-5xl">{experiment.title}</h1><p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">{experiment.summary}</p></div><button type="button" onClick={() => setRecording(!recording)} className={`inline-flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold transition ${recording ? 'bg-destructive text-destructive-foreground' : 'bg-primary text-primary-foreground shadow-[0_10px_25px_hsl(var(--primary)/.15)] hover:-translate-y-0.5'}`} data-testid="button-toggle-recording">{recording ? <><span className="recording-pulse h-2.5 w-2.5 rounded-full bg-white" />{t.stop}</> : <><AudioLines size={17} />{t.recording}</>}</button></div>
    {recording && <div className="mt-5 flex items-center gap-3 rounded-xl border border-destructive/30 bg-destructive/8 px-4 py-3 text-xs text-destructive animate-in" data-testid="status-recording"><span className="recording-pulse h-2 w-2 rounded-full bg-destructive" /><span className="font-semibold">{t.recordingOn}</span><span className="text-destructive/70">Audio stays on this device in the demo.</span></div>}
    <div className="mt-10 flex gap-5 overflow-x-auto border-b border-border" role="tablist">{([['overview', t.overview, LayoutDashboard], ['notes', t.notes, FileText], ['insights', t.insights, Sparkles]] as const).map(([value, label, Icon]) => <button type="button" key={value} onClick={() => setTab(value)} className={`flex shrink-0 items-center gap-2 border-b-2 px-1 pb-3 text-xs font-semibold transition ${tab === value ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`} role="tab" aria-selected={tab === value} data-testid={`tab-${value}`}><Icon size={14} />{label}</button>)}</div>
    {tab === 'overview' && <div className="mt-7 grid gap-5 lg:grid-cols-[1.35fr_.65fr]"><NotesPanel experiment={experiment} language={language} onAddNote={addNote} /><aside className="space-y-5"><div className="rounded-2xl border border-border bg-card p-5 sm:p-6"><div className="flex items-start justify-between"><div><p className="text-xs font-semibold">{t.originality}</p><p className="mt-1 max-w-[150px] text-xs leading-5 text-muted-foreground">A local signal based on your recent threads.</p></div><Lightbulb size={17} className="text-primary" /></div><div className="mt-5 flex items-center gap-4"><CircularScore value={experiment.originality} /><div><span className="text-sm font-semibold">{experiment.originality > 80 ? 'Distinctive thread' : 'Promising direction'}</span><p className="mt-1 text-xs leading-5 text-muted-foreground">Keep capturing context as the pattern develops.</p></div></div></div><div className="rounded-2xl border border-border bg-card p-5 sm:p-6"><div className="flex items-center gap-2"><Sparkles size={16} className="text-primary" /><p className="text-xs font-semibold">{t.similar}</p></div><p className="mt-4 text-2xl font-semibold tracking-[-.05em]">Low overlap</p><p className="mt-2 text-xs leading-5 text-muted-foreground">{t.similarSub}. Your closest thread is <span className="font-semibold text-foreground">18%</span> related.</p><div className="mt-5 h-1.5 overflow-hidden rounded-full bg-muted"><div className="h-full w-[18%] rounded-full bg-primary" /></div></div></aside></div>}
    {tab === 'notes' && <div className="mt-7 max-w-3xl"><NotesPanel experiment={experiment} language={language} onAddNote={addNote} /></div>}
    {tab === 'insights' && <div className="mt-7 grid gap-5 md:grid-cols-2"><div className="rounded-2xl border border-border bg-card p-6"><div className="flex items-center gap-2 text-primary"><Sparkles size={17} /><h3 className="text-sm font-semibold">Signal summary</h3></div><p className="mt-5 text-lg font-semibold leading-7 tracking-[-.03em]">The useful detail is arriving before the conclusion.</p><p className="mt-3 text-sm leading-6 text-muted-foreground">MindTrace sees a consistent observation rhythm in this thread. Keep the raw notes close; the hypothesis is still moving.</p></div><div className="rounded-2xl border border-border bg-card p-6"><div className="flex items-center gap-2 text-primary"><Tag size={17} /><h3 className="text-sm font-semibold">{t.related}</h3></div><div className="mt-5 flex flex-wrap gap-2">{experiment.tags.map((tag) => <span key={tag} className="rounded-full bg-muted px-3 py-1.5 text-xs text-muted-foreground">{tag}</span>)}</div><div className="mt-8 rounded-xl bg-primary/8 p-4 text-xs leading-5 text-muted-foreground">Related-work suggestions will become richer when your research library is connected.</div></div></div>}
  </div>;
}

function SettingsPage({ language, setLanguage, theme, setTheme }: { language: Language; setLanguage: (value: Language) => void; theme: Theme; setTheme: (value: Theme) => void }) {
  const t = translations[language];
  return <div className="animate-in max-w-3xl"><p className="font-mono text-[10px] uppercase tracking-[.25em] text-primary">MindTrace / preferences</p><h1 className="mt-3 text-3xl font-semibold tracking-[-.055em]">{t.settings}</h1><p className="mt-2 text-sm text-muted-foreground">Shape the workspace around the way you think.</p><div className="mt-9 overflow-hidden rounded-2xl border border-border bg-card"><div className="flex items-start gap-4 border-b border-border p-5 sm:p-7"><div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent/45 text-primary"><div className="text-sm font-bold">NR</div></div><div><h2 className="text-sm font-semibold">{t.profile}</h2><p className="mt-1 text-xs text-muted-foreground">Dr. Noor Rahman · Materials lab</p><span className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-2.5 py-1 text-[10px] font-semibold text-primary"><Check size={11} />{t.saved}</span></div></div><div className="border-b border-border p-5 sm:p-7"><div className="flex items-center gap-3"><Sun size={17} className="text-primary" /><div><h2 className="text-sm font-semibold">{t.appearance}</h2><p className="mt-1 text-xs text-muted-foreground">{t.theme}</p></div></div><div className="mt-5 grid grid-cols-2 gap-3"><button type="button" onClick={() => setTheme('light')} className={`flex items-center gap-3 rounded-xl border p-3 text-left transition ${theme === 'light' ? 'border-primary bg-primary/8' : 'border-border hover:border-primary/40'}`} data-testid="button-theme-light"><Sun size={16} className={theme === 'light' ? 'text-primary' : 'text-muted-foreground'} /><span className="text-xs font-semibold">{t.light}</span>{theme === 'light' && <Check size={14} className="ms-auto text-primary" />}</button><button type="button" onClick={() => setTheme('dark')} className={`flex items-center gap-3 rounded-xl border p-3 text-left transition ${theme === 'dark' ? 'border-primary bg-primary/8' : 'border-border hover:border-primary/40'}`} data-testid="button-theme-dark"><Moon size={16} className={theme === 'dark' ? 'text-primary' : 'text-muted-foreground'} /><span className="text-xs font-semibold">{t.dark}</span>{theme === 'dark' && <Check size={14} className="ms-auto text-primary" />}</button></div></div><div className="p-5 sm:p-7"><div className="flex items-center gap-3"><SlidersHorizontal size={17} className="text-primary" /><div><h2 className="text-sm font-semibold">{t.langSetting}</h2><p className="mt-1 text-xs text-muted-foreground">Choose the language for your workspace.</p></div></div><div className="mt-5 flex gap-3"><button type="button" onClick={() => setLanguage('en')} className={`rounded-xl border px-4 py-2.5 text-xs font-semibold transition ${language === 'en' ? 'border-primary bg-primary/8 text-primary' : 'border-border text-muted-foreground hover:border-primary/40'}`} data-testid="button-language-english">English</button><button type="button" onClick={() => setLanguage('ar')} className={`rounded-xl border px-4 py-2.5 text-xs font-semibold transition ${language === 'ar' ? 'border-primary bg-primary/8 text-primary' : 'border-border text-muted-foreground hover:border-primary/40'}`} data-testid="button-language-arabic">العربية</button></div></div></div></div>;
}

function App() {
  const [language, setLanguage] = useState<Language>('en');
  const [theme, setTheme] = useState<Theme>('light');
  const [experiments, setExperiments] = useState<Experiment[]>(initialExperiments);
  const [, setLocation] = useLocation();
  useEffect(() => { document.documentElement.classList.toggle('dark', theme === 'dark'); document.documentElement.lang = language; document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr'; }, [theme, language]);
  return <ErrorBoundary resetKey={location.pathname}><Switch><Route path="/"><SignInPage language={language} setLanguage={setLanguage} onEnter={() => setLocation('/dashboard')} /></Route><Route path="/dashboard"><AppShell language={language} setLanguage={setLanguage} theme={theme} setTheme={setTheme}><DashboardPage experiments={experiments} setExperiments={setExperiments} language={language} theme={theme} setTheme={setTheme} /></AppShell></Route><Route path="/experiments/:id"><AppShell language={language} setLanguage={setLanguage} theme={theme} setTheme={setTheme}><ExperimentPage experiments={experiments} setExperiments={setExperiments} language={language} /></AppShell></Route><Route path="/settings"><AppShell language={language} setLanguage={setLanguage} theme={theme} setTheme={setTheme}><SettingsPage language={language} setLanguage={setLanguage} theme={theme} setTheme={setTheme} /></AppShell></Route><Route component={NotFound} /></Switch></ErrorBoundary>;
}

export default App;